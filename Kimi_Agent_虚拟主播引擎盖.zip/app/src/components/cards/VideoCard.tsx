import { Play, Users, Clock, Eye } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import type { LiveStream, Video } from '@/data/mockData';

interface VideoCardProps {
  content: LiveStream | Video;
  type: 'live' | 'video';
  onClick?: () => void;
}

export function VideoCard({ content, type, onClick }: VideoCardProps) {
  const isLive = type === 'live';
  const liveContent = content as LiveStream;
  const videoContent = content as Video;

  return (
    <div 
      onClick={onClick}
      className="group cursor-pointer rounded-xl overflow-hidden bg-[#1a1a1a] border border-[#3d3d3d]
        hover:border-[#ff0055]/50 hover:shadow-lg hover:shadow-[#ff0055]/10
        transition-all duration-300 hover:-translate-y-1"
    >
      {/* Thumbnail */}
      <div className="relative aspect-video overflow-hidden">
        <img 
          src={content.thumbnail} 
          alt={content.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        
        {/* Overlay */}
        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300
          flex items-center justify-center">
          <div className="w-14 h-14 rounded-full bg-[#ff0055] flex items-center justify-center
            transform scale-75 group-hover:scale-100 transition-transform duration-300">
            <Play className="w-6 h-6 text-white ml-1" fill="white" />
          </div>
        </div>

        {/* Live Badge */}
        {isLive && (
          <div className="absolute top-3 left-3 flex items-center gap-2">
            <Badge className="bg-[#ff0055] text-white border-0 px-2 py-0.5 text-xs font-medium live-indicator">
              LIVE
            </Badge>
            <Badge className="bg-black/70 text-white border-0 px-2 py-0.5 text-xs">
              <Users className="w-3 h-3 mr-1" />
              {liveContent.viewers}
            </Badge>
          </div>
        )}

        {/* Duration Badge */}
        {!isLive && (
          <div className="absolute bottom-3 right-3">
            <Badge className="bg-black/80 text-white border-0 px-2 py-0.5 text-xs">
              <Clock className="w-3 h-3 mr-1" />
              {videoContent.duration}
            </Badge>
          </div>
        )}
      </div>

      {/* Content */}
      <div className="p-4">
        {/* Title */}
        <h3 className="text-white font-medium text-sm line-clamp-2 mb-3 group-hover:text-[#ff0055] transition-colors">
          {content.title}
        </h3>

        {/* VTuber Info */}
        <div className="flex items-center gap-3">
          <img 
            src={content.vtuber.avatar} 
            alt={content.vtuber.name}
            className="w-8 h-8 rounded-full bg-[#2d2d2d]"
          />
          <div className="flex-1 min-w-0">
            <p className="text-white text-sm font-medium truncate">
              {content.vtuber.name}
            </p>
            <p className="text-[#8a8a8a] text-xs">
              {content.vtuber.group}
            </p>
          </div>
        </div>

        {/* Tags & Stats */}
        <div className="mt-3 flex items-center justify-between">
          <div className="flex gap-1 flex-wrap">
            {content.tags.slice(0, 2).map((tag, idx) => (
              <span 
                key={idx}
                className="text-[10px] px-2 py-0.5 bg-[#2d2d2d] text-[#8a8a8a] rounded-full"
              >
                {tag}
              </span>
            ))}
          </div>
          
          {!isLive && (
            <div className="flex items-center gap-1 text-[#8a8a8a] text-xs">
              <Eye className="w-3 h-3" />
              <span>{videoContent.views}</span>
            </div>
          )}
        </div>

        {/* Published Time */}
        {!isLive && (
          <p className="mt-2 text-[#8a8a8a] text-xs">
            {videoContent.publishedAt}
          </p>
        )}
      </div>
    </div>
  );
}
