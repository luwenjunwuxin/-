import { Play, Clock } from 'lucide-react';
import type { Radio } from '@/data/mockData';

interface RadioCardProps {
  radio: Radio;
  onClick?: () => void;
}

export function RadioCard({ radio, onClick }: RadioCardProps) {
  return (
    <div 
      onClick={onClick}
      className="group cursor-pointer flex-shrink-0 w-[280px] rounded-xl overflow-hidden 
        bg-[#1a1a1a] border border-[#3d3d3d]
        hover:border-[#00d4ff]/50 hover:shadow-lg hover:shadow-[#00d4ff]/10
        transition-all duration-300 hover:-translate-y-1"
    >
      {/* Cover */}
      <div className="relative h-[160px] overflow-hidden">
        <img 
          src={radio.cover} 
          alt={radio.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        
        {/* Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
        
        {/* Play Button */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <div className="w-14 h-14 rounded-full bg-[#00d4ff] flex items-center justify-center
            transform scale-75 group-hover:scale-100 transition-transform duration-300 shadow-lg shadow-[#00d4ff]/30">
            <Play className="w-6 h-6 text-white ml-1" fill="white" />
          </div>
        </div>

        {/* Duration */}
        <div className="absolute bottom-3 right-3 flex items-center gap-1 text-white text-xs bg-black/60 px-2 py-1 rounded-full">
          <Clock className="w-3 h-3" />
          <span>{radio.duration}</span>
        </div>
      </div>

      {/* Info */}
      <div className="p-4">
        <h3 className="text-white font-medium text-sm mb-2 group-hover:text-[#00d4ff] transition-colors line-clamp-1">
          {radio.title}
        </h3>
        
        <div className="flex items-center gap-2">
          <img 
            src={radio.vtuber.avatar} 
            alt={radio.vtuber.name}
            className="w-6 h-6 rounded-full bg-[#2d2d2d]"
          />
          <span className="text-[#8a8a8a] text-xs">{radio.vtuber.name}</span>
        </div>
      </div>
    </div>
  );
}
