import { useState } from 'react';
import { Youtube, Twitter, ExternalLink, Heart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import type { VTuber } from '@/data/mockData';

interface ChannelCardProps {
  vtuber: VTuber;
}

export function ChannelCard({ vtuber }: ChannelCardProps) {
  const [isFollowing, setIsFollowing] = useState(false);

  return (
    <div className="group flex items-center gap-4 p-4 bg-[#1a1a1a] border border-[#3d3d3d] rounded-xl
      hover:border-[#ff0055]/30 hover:bg-[#1f1f1f] transition-all duration-300">
      
      {/* Avatar */}
      <div className="relative">
        <img 
          src={vtuber.avatar} 
          alt={vtuber.name}
          className="w-14 h-14 rounded-full bg-[#2d2d2d] group-hover:ring-2 group-hover:ring-[#ff0055]/50 transition-all"
        />
        <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-[#ff0055] rounded-full flex items-center justify-center">
          <span className="text-[10px] text-white font-bold">V</span>
        </div>
      </div>

      {/* Info */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-1">
          <h3 className="text-white font-medium truncate group-hover:text-[#ff0055] transition-colors">
            {vtuber.name}
          </h3>
          <span className="text-[#8a8a8a] text-xs">{vtuber.group}</span>
        </div>
        
        <div className="flex items-center gap-3 text-[#8a8a8a] text-xs mb-2">
          <span>{vtuber.subscribers} 订阅</span>
          <span>•</span>
          <span>{vtuber.videoCount} 视频</span>
        </div>

        {/* Tags */}
        <div className="flex gap-1 flex-wrap">
          {vtuber.tags.map((tag, idx) => (
            <Badge 
              key={idx}
              variant="secondary"
              className="bg-[#2d2d2d] text-[#8a8a8a] border-0 text-[10px] hover:bg-[#3d3d3d]"
            >
              {tag}
            </Badge>
          ))}
        </div>
      </div>

      {/* Social Links */}
      <div className="flex items-center gap-1">
        {vtuber.socialLinks.youtube && (
          <Button 
            variant="ghost" 
            size="icon"
            className="w-8 h-8 text-[#8a8a8a] hover:text-[#ff0055] hover:bg-[#ff0055]/10"
            onClick={(e) => e.stopPropagation()}
          >
            <Youtube className="w-4 h-4" />
          </Button>
        )}
        {vtuber.socialLinks.twitter && (
          <Button 
            variant="ghost" 
            size="icon"
            className="w-8 h-8 text-[#8a8a8a] hover:text-[#00d4ff] hover:bg-[#00d4ff]/10"
            onClick={(e) => e.stopPropagation()}
          >
            <Twitter className="w-4 h-4" />
          </Button>
        )}
        <Button 
          variant="ghost" 
          size="icon"
          className="w-8 h-8 text-[#8a8a8a] hover:text-white hover:bg-[#2d2d2d]"
          onClick={(e) => e.stopPropagation()}
        >
          <ExternalLink className="w-4 h-4" />
        </Button>
      </div>

      {/* Follow Button */}
      <Button
        variant={isFollowing ? "default" : "outline"}
        size="sm"
        onClick={(e) => {
          e.stopPropagation();
          setIsFollowing(!isFollowing);
        }}
        className={`
          min-w-[80px] rounded-full text-xs
          ${isFollowing 
            ? 'bg-[#ff0055] hover:bg-[#ff0055]/80 text-white border-0' 
            : 'border-[#ff0055] text-[#ff0055] hover:bg-[#ff0055]/10'
          }
        `}
      >
        {isFollowing ? (
          <>
            <Heart className="w-3 h-3 mr-1" fill="currentColor" />
            已关注
          </>
        ) : (
          <>
            <Heart className="w-3 h-3 mr-1" />
            关注
          </>
        )}
      </Button>
    </div>
  );
}
