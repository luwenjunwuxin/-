import { useState, useRef, useEffect } from 'react';
import { 
  Play, 
  Pause, 
  SkipBack, 
  SkipForward, 
  Volume2, 
  VolumeX,
  ListMusic,
  Repeat,
  Shuffle,
  ChevronUp,
  Heart
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';

interface BottomPlayerProps {
  isPlaying: boolean;
  onPlayPause: () => void;
  currentTrack?: {
    title: string;
    artist: string;
    thumbnail: string;
    duration: number;
  } | null;
}

export function BottomPlayer({ isPlaying, onPlayPause, currentTrack }: BottomPlayerProps) {
  const [volume, setVolume] = useState(80);
  const [isMuted, setIsMuted] = useState(false);
  const [progress, setProgress] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [isLiked, setIsLiked] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const progressInterval = useRef<ReturnType<typeof setInterval> | null>(null);

  const defaultTrack = {
    title: '未在播放',
    artist: '选择一首歌曲开始',
    thumbnail: '',
    duration: 0
  };

  const track = currentTrack || defaultTrack;

  useEffect(() => {
    if (isPlaying) {
      progressInterval.current = setInterval(() => {
        setProgress((prev) => {
          if (prev >= 100) {
            setCurrentTime(0);
            return 0;
          }
          setCurrentTime((prevTime) => prevTime + 1);
          return prev + 0.5;
        });
      }, 1000);
    } else {
      if (progressInterval.current) {
        clearInterval(progressInterval.current);
      }
    }

    return () => {
      if (progressInterval.current) {
        clearInterval(progressInterval.current);
      }
    };
  }, [isPlaying]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleProgressChange = (value: number[]) => {
    setProgress(value[0]);
    setCurrentTime(Math.floor((value[0] / 100) * track.duration));
  };

  return (
    <>
      {/* Bottom Player */}
      <div className="fixed bottom-0 left-0 right-0 h-20 bg-[#0a0a0a] border-t border-[#2d2d2d] z-50">
        <div className="h-full flex items-center justify-between px-4 lg:pl-[256px]">
          {/* Track Info */}
          <div className="flex items-center gap-4 w-[280px]">
            <div 
              className="w-14 h-14 rounded-lg bg-[#1a1a1a] overflow-hidden flex-shrink-0 cursor-pointer"
              onClick={() => setIsExpanded(!isExpanded)}
            >
              {track.thumbnail ? (
                <img 
                  src={track.thumbnail} 
                  alt={track.title}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <ListMusic className="w-6 h-6 text-[#8a8a8a]" />
                </div>
              )}
            </div>
            <div className="min-w-0">
              <h4 className="text-white text-sm font-medium truncate cursor-pointer hover:text-[#ff0055] transition-colors"
                onClick={() => setIsExpanded(!isExpanded)}>
                {track.title}
              </h4>
              <p className="text-[#8a8a8a] text-xs truncate">{track.artist}</p>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsLiked(!isLiked)}
              className={`w-8 h-8 ${isLiked ? 'text-[#ff0055]' : 'text-[#8a8a8a]'} hover:text-[#ff0055]`}
            >
              <Heart className="w-4 h-4" fill={isLiked ? 'currentColor' : 'none'} />
            </Button>
          </div>

          {/* Controls */}
          <div className="flex flex-col items-center flex-1 max-w-xl px-8">
            {/* Control Buttons */}
            <div className="flex items-center gap-4 mb-2">
              <Button 
                variant="ghost" 
                size="icon"
                className="w-8 h-8 text-[#8a8a8a] hover:text-white hover:bg-[#1a1a1a]"
              >
                <Shuffle className="w-4 h-4" />
              </Button>
              
              <Button 
                variant="ghost" 
                size="icon"
                className="w-10 h-10 text-white hover:bg-[#1a1a1a]"
              >
                <SkipBack className="w-5 h-5" fill="currentColor" />
              </Button>
              
              <Button 
                onClick={onPlayPause}
                className="w-10 h-10 rounded-full gradient-primary hover:opacity-90 flex items-center justify-center"
              >
                {isPlaying ? (
                  <Pause className="w-5 h-5 text-white" fill="white" />
                ) : (
                  <Play className="w-5 h-5 text-white ml-0.5" fill="white" />
                )}
              </Button>
              
              <Button 
                variant="ghost" 
                size="icon"
                className="w-10 h-10 text-white hover:bg-[#1a1a1a]"
              >
                <SkipForward className="w-5 h-5" fill="currentColor" />
              </Button>
              
              <Button 
                variant="ghost" 
                size="icon"
                className="w-8 h-8 text-[#8a8a8a] hover:text-white hover:bg-[#1a1a1a]"
              >
                <Repeat className="w-4 h-4" />
              </Button>
            </div>

            {/* Progress Bar */}
            <div className="w-full flex items-center gap-3">
              <span className="text-[#8a8a8a] text-xs w-10 text-right">
                {formatTime(currentTime)}
              </span>
              <Slider
                value={[progress]}
                onValueChange={handleProgressChange}
                max={100}
                step={1}
                className="flex-1"
              />
              <span className="text-[#8a8a8a] text-xs w-10">
                {formatTime(track.duration)}
              </span>
            </div>
          </div>

          {/* Volume & Extra Controls */}
          <div className="flex items-center gap-2 w-[200px] justify-end">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsMuted(!isMuted)}
              className="w-8 h-8 text-[#8a8a8a] hover:text-white hover:bg-[#1a1a1a]"
            >
              {isMuted || volume === 0 ? (
                <VolumeX className="w-4 h-4" />
              ) : (
                <Volume2 className="w-4 h-4" />
              )}
            </Button>
            
            <Slider
              value={[isMuted ? 0 : volume]}
              onValueChange={(value) => {
                setVolume(value[0]);
                setIsMuted(false);
              }}
              max={100}
              step={1}
              className="w-24"
            />
            
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsExpanded(!isExpanded)}
              className="w-8 h-8 text-[#8a8a8a] hover:text-white hover:bg-[#1a1a1a] ml-2"
            >
              <ChevronUp className={`w-5 h-5 transition-transform ${isExpanded ? 'rotate-180' : ''}`} />
            </Button>
          </div>
        </div>
      </div>

      {/* Expanded Player Overlay */}
      {isExpanded && (
        <div 
          className="fixed inset-0 bg-black/80 z-40"
          onClick={() => setIsExpanded(false)}
        />
      )}
    </>
  );
}
