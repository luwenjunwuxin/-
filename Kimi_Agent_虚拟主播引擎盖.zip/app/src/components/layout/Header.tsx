import { useState } from 'react';
import { 
  Menu, 
  Search, 
  Bell, 
  User,
  Filter,
  X
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

interface HeaderProps {
  onMenuClick: () => void;
  onSearch?: (query: string) => void;
}

export function Header({ onMenuClick, onSearch }: HeaderProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchFocused, setIsSearchFocused] = useState(false);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (onSearch && searchQuery.trim()) {
      onSearch(searchQuery);
    }
  };

  return (
    <header className="fixed top-0 left-0 right-0 h-16 glass-effect border-b border-[#2d2d2d] z-30">
      <div className="h-full flex items-center justify-between px-4 lg:pl-[256px]">
        {/* Left Section */}
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={onMenuClick}
            className="lg:hidden text-white hover:bg-[#1a1a1a]"
          >
            <Menu className="w-5 h-5" />
          </Button>

          {/* Search Bar */}
          <form 
            onSubmit={handleSearch}
            className={`
              relative flex items-center transition-all duration-300
              ${isSearchFocused ? 'w-[400px]' : 'w-[280px]'}
            `}
          >
            <div className="relative w-full">
              <Search className={`
                absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 transition-colors
                ${isSearchFocused ? 'text-[#ff0055]' : 'text-[#8a8a8a]'}
              `} />
              <Input
                type="text"
                placeholder="搜索VTuber、视频、标签..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onFocus={() => setIsSearchFocused(true)}
                onBlur={() => setIsSearchFocused(false)}
                className={`
                  w-full pl-10 pr-10 py-2 bg-[#1a1a1a] border-[#3d3d3d] rounded-full
                  text-sm text-white placeholder:text-[#8a8a8a]
                  focus:border-[#ff0055] focus:ring-1 focus:ring-[#ff0055]/30
                  transition-all duration-200
                `}
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[#8a8a8a] hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
          </form>

          {/* Filter Button */}
          <Button
            variant="ghost"
            size="icon"
            className="hidden sm:flex text-[#8a8a8a] hover:text-white hover:bg-[#1a1a1a]"
          >
            <Filter className="w-4 h-4" />
          </Button>
        </div>

        {/* Right Section */}
        <div className="flex items-center gap-2">
          {/* Notifications */}
          <Button
            variant="ghost"
            size="icon"
            className="relative text-[#8a8a8a] hover:text-white hover:bg-[#1a1a1a]"
          >
            <Bell className="w-5 h-5" />
            <span className="absolute top-1 right-1 w-2 h-2 bg-[#ff0055] rounded-full" />
          </Button>

          {/* User Avatar */}
          <Button
            variant="ghost"
            size="icon"
            className="w-9 h-9 rounded-full bg-gradient-to-br from-[#ff0055] to-[#7000ff] p-0.5"
          >
            <div className="w-full h-full rounded-full bg-[#1a1a1a] flex items-center justify-center">
              <User className="w-4 h-4 text-white" />
            </div>
          </Button>
        </div>
      </div>
    </header>
  );
}
