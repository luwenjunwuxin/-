import { useState } from 'react';
import { 
  Home, 
  Users, 
  ListMusic, 
  Heart, 
  Settings, 
  Info,
  ChevronDown,
  Radio,
  Video,
  Mic2
} from 'lucide-react';
import { categories } from '@/data/mockData';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export function Sidebar({ isOpen, onClose, activeTab, onTabChange }: SidebarProps) {
  const [expandedCategories, setExpandedCategories] = useState(true);

  const mainNavItems = [
    { id: 'home', name: '首页', icon: Home },
    { id: 'channels', name: '频道', icon: Users },
    { id: 'playlists', name: '播放列表', icon: ListMusic },
    { id: 'favorites', name: '收藏夹', icon: Heart },
  ];

  const contentTypes = [
    { id: 'live', name: '直播中', icon: Radio },
    { id: 'videos', name: '录播', icon: Video },
    { id: 'radio', name: '电台', icon: Mic2 },
  ];

  return (
    <>
      {/* Mobile Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/60 z-40 lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <aside 
        className={`
          fixed left-0 top-0 h-full w-[240px] bg-[#0a0a0a] border-r border-[#2d2d2d]
          z-50 transition-transform duration-300 ease-out
          ${isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
        `}
      >
        {/* Logo */}
        <div className="h-16 flex items-center px-6 border-b border-[#2d2d2d]">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center overflow-hidden">
              <img src="/midas.png" alt="点金手" className="w-full h-full object-cover" />
            </div>
            <span className="text-lg font-bold text-white">
              虚拟主播领域引擎盖
            </span>
          </div>
        </div>

        {/* Navigation */}
        <div className="py-4 overflow-y-auto h-[calc(100%-64px)] scrollbar-hide">
          {/* Main Navigation */}
          <nav className="px-3 mb-6">
            <p className="text-xs text-[#8a8a8a] uppercase tracking-wider mb-2 px-3">
              主导航
            </p>
            {mainNavItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onTabChange(item.id)}
                  className={`
                    w-full flex items-center gap-3 px-3 py-2.5 rounded-lg mb-1
                    transition-all duration-200 relative group
                    ${isActive 
                      ? 'bg-[#ff0055]/20 text-white' 
                      : 'text-[#8a8a8a] hover:bg-[#1a1a1a] hover:text-white'
                    }
                  `}
                >
                  {isActive && (
                    <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-6 bg-[#ff0055] rounded-r-full" />
                  )}
                  <Icon className={`w-5 h-5 ${isActive ? 'text-[#ff0055]' : ''}`} />
                  <span className="text-sm font-medium">{item.name}</span>
                </button>
              );
            })}
          </nav>

          {/* Content Types */}
          <nav className="px-3 mb-6">
            <p className="text-xs text-[#8a8a8a] uppercase tracking-wider mb-2 px-3">
              内容类型
            </p>
            {contentTypes.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg mb-1
                    text-[#8a8a8a] hover:bg-[#1a1a1a] hover:text-white transition-all duration-200"
                >
                  <Icon className="w-5 h-5" />
                  <span className="text-sm font-medium">{item.name}</span>
                </button>
              );
            })}
          </nav>

          {/* Categories */}
          <div className="px-3 mb-6">
            <button 
              onClick={() => setExpandedCategories(!expandedCategories)}
              className="w-full flex items-center justify-between px-3 mb-2 text-[#8a8a8a]"
            >
              <span className="text-xs uppercase tracking-wider">分类</span>
              <ChevronDown 
                className={`w-4 h-4 transition-transform duration-200 ${expandedCategories ? '' : '-rotate-90'}`} 
              />
            </button>
            
            {expandedCategories && (
              <div className="space-y-1">
                {categories.map((cat) => (
                  <button
                    key={cat.id}
                    className="w-full flex items-center gap-3 px-3 py-2 rounded-lg
                      text-[#8a8a8a] hover:bg-[#1a1a1a] hover:text-white transition-all duration-200"
                  >
                    <span className="text-sm">{cat.name}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Bottom Actions */}
          <nav className="px-3 mt-auto">
            <div className="border-t border-[#2d2d2d] pt-4">
              <button
                className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg mb-1
                  text-[#8a8a8a] hover:bg-[#1a1a1a] hover:text-white transition-all duration-200"
              >
                <Settings className="w-5 h-5" />
                <span className="text-sm font-medium">设置</span>
              </button>
              <button
                className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg
                  text-[#8a8a8a] hover:bg-[#1a1a1a] hover:text-white transition-all duration-200"
              >
                <Info className="w-5 h-5" />
                <span className="text-sm font-medium">关于</span>
              </button>
            </div>
          </nav>
        </div>
      </aside>
    </>
  );
}
