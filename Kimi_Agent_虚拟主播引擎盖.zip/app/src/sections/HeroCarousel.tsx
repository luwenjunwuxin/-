import { useState, useEffect, useCallback } from 'react';
import { ChevronLeft, ChevronRight, Play, Radio } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { liveStreams } from '@/data/mockData';

export function HeroCarousel() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  const featuredStreams = liveStreams.slice(0, 3);

  const nextSlide = useCallback(() => {
    setCurrentIndex((prev) => (prev + 1) % featuredStreams.length);
  }, [featuredStreams.length]);

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev - 1 + featuredStreams.length) % featuredStreams.length);
  };

  useEffect(() => {
    if (isPaused) return;
    
    const interval = setInterval(nextSlide, 5000);
    return () => clearInterval(interval);
  }, [isPaused, nextSlide]);

  const currentStream = featuredStreams[currentIndex];

  return (
    <div 
      className="relative w-full h-[320px] rounded-2xl overflow-hidden mb-8"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
    >
      {/* Background Image */}
      <div className="absolute inset-0">
        <img 
          src={currentStream.thumbnail} 
          alt={currentStream.title}
          className="w-full h-full object-cover transition-transform duration-700"
        />
        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#0f0f0f] via-[#0f0f0f]/60 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0f0f0f]/80 to-transparent" />
      </div>

      {/* Content */}
      <div className="absolute inset-0 flex items-end p-8">
        <div className="max-w-xl animate-fade-in">
          {/* Live Badge */}
          <div className="flex items-center gap-3 mb-4">
            <span className="flex items-center gap-2 px-3 py-1 bg-[#ff0055] rounded-full text-white text-sm font-medium live-indicator">
              <Radio className="w-4 h-4" />
              LIVE
            </span>
            <span className="text-white/80 text-sm">
              {currentStream.viewers} 正在观看
            </span>
          </div>

          {/* Title */}
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-3 line-clamp-2">
            {currentStream.title}
          </h2>

          {/* VTuber Info */}
          <div className="flex items-center gap-3 mb-6">
            <img 
              src={currentStream.vtuber.avatar} 
              alt={currentStream.vtuber.name}
              className="w-10 h-10 rounded-full bg-[#2d2d2d]"
            />
            <div>
              <p className="text-white font-medium">{currentStream.vtuber.name}</p>
              <p className="text-white/60 text-sm">{currentStream.vtuber.group}</p>
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-3">
            <Button 
              className="gradient-primary hover:opacity-90 text-white rounded-full px-6"
            >
              <Play className="w-4 h-4 mr-2" fill="white" />
              立即观看
            </Button>
            <Button 
              variant="outline"
              className="border-white/30 text-white hover:bg-white/10 rounded-full px-6"
            >
              查看详情
            </Button>
          </div>
        </div>
      </div>

      {/* Navigation Arrows */}
      <button
        onClick={prevSlide}
        className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/50 
          text-white flex items-center justify-center hover:bg-black/70 transition-colors"
      >
        <ChevronLeft className="w-5 h-5" />
      </button>
      <button
        onClick={nextSlide}
        className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/50 
          text-white flex items-center justify-center hover:bg-black/70 transition-colors"
      >
        <ChevronRight className="w-5 h-5" />
      </button>

      {/* Dots Indicator */}
      <div className="absolute bottom-4 right-4 flex items-center gap-2">
        {featuredStreams.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentIndex(index)}
            className={`
              h-2 rounded-full transition-all duration-300
              ${index === currentIndex 
                ? 'w-8 bg-[#ff0055]' 
                : 'w-2 bg-white/40 hover:bg-white/60'
              }
            `}
          />
        ))}
      </div>
    </div>
  );
}
