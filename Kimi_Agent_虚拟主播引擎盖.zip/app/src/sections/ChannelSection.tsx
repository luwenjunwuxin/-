import { ChevronRight } from 'lucide-react';
import { ChannelCard } from '@/components/cards/ChannelCard';
import { vtubers } from '@/data/mockData';

export function ChannelSection() {
  return (
    <section className="mb-10 animate-slide-up" style={{ animationDelay: '400ms' }}>
      {/* Header */}
      <div className="flex items-center justify-between mb-5">
        <div className="flex items-center gap-3">
          <h2 className="text-2xl font-bold text-white">推荐频道</h2>
          <span className="text-[#8a8a8a] text-sm">
            {vtubers.length} 位VTuber
          </span>
        </div>
        <button className="flex items-center gap-1 text-[#8a8a8a] hover:text-[#ff0055] transition-colors text-sm">
          查看全部
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      {/* Channel List */}
      <div className="space-y-3">
        {vtubers.map((vtuber) => (
          <ChannelCard key={vtuber.id} vtuber={vtuber} />
        ))}
      </div>
    </section>
  );
}
