import { useRef } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { RadioCard } from '@/components/cards/RadioCard';
import { radios } from '@/data/mockData';

interface RadioSectionProps {
  onRadioClick?: (radio: typeof radios[0]) => void;
}

export function RadioSection({ onRadioClick }: RadioSectionProps) {
  const scrollRef = useRef<HTMLDivElement>(null);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const scrollAmount = 300;
      scrollRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section className="mb-10 animate-slide-up" style={{ animationDelay: '300ms' }}>
      {/* Header */}
      <div className="flex items-center justify-between mb-5">
        <div className="flex items-center gap-3">
          <h2 className="text-2xl font-bold text-white">精选电台</h2>
          <span className="text-[#8a8a8a] text-sm">
            放松身心的音频内容
          </span>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={() => scroll('left')}
            className="w-8 h-8 rounded-full bg-[#1a1a1a] border border-[#3d3d3d] 
              text-[#8a8a8a] hover:text-white hover:border-[#00d4ff] transition-colors
              flex items-center justify-center"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <button 
            onClick={() => scroll('right')}
            className="w-8 h-8 rounded-full bg-[#1a1a1a] border border-[#3d3d3d] 
              text-[#8a8a8a] hover:text-white hover:border-[#00d4ff] transition-colors
              flex items-center justify-center"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Horizontal Scroll */}
      <div 
        ref={scrollRef}
        className="flex gap-5 overflow-x-auto scrollbar-hide pb-2"
      >
        {radios.map((radio) => (
          <RadioCard 
            key={radio.id} 
            radio={radio}
            onClick={() => onRadioClick?.(radio)}
          />
        ))}
      </div>
    </section>
  );
}
