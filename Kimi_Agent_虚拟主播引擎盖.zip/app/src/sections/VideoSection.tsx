import { ChevronRight } from 'lucide-react';
import { VideoCard } from '@/components/cards/VideoCard';
import { videos } from '@/data/mockData';

interface VideoSectionProps {
  onVideoClick?: (video: typeof videos[0]) => void;
}

export function VideoSection({ onVideoClick }: VideoSectionProps) {
  return (
    <section className="mb-10 animate-slide-up" style={{ animationDelay: '200ms' }}>
      {/* Header */}
      <div className="flex items-center justify-between mb-5">
        <div className="flex items-center gap-3">
          <h2 className="text-2xl font-bold text-white">最新录播</h2>
          <span className="text-[#8a8a8a] text-sm">
            今日更新 {videos.length} 个视频
          </span>
        </div>
        <button className="flex items-center gap-1 text-[#8a8a8a] hover:text-[#ff0055] transition-colors text-sm">
          查看更多
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
        {videos.map((video) => (
          <VideoCard 
            key={video.id} 
            content={video} 
            type="video"
            onClick={() => onVideoClick?.(video)}
          />
        ))}
      </div>
    </section>
  );
}
