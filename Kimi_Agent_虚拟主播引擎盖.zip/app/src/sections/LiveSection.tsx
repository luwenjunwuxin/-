import { ChevronRight } from 'lucide-react';
import { VideoCard } from '@/components/cards/VideoCard';
import { liveStreams } from '@/data/mockData';

interface LiveSectionProps {
  onVideoClick?: (stream: typeof liveStreams[0]) => void;
}

export function LiveSection({ onVideoClick }: LiveSectionProps) {
  return (
    <section className="mb-10 animate-slide-up" style={{ animationDelay: '100ms' }}>
      {/* Header */}
      <div className="flex items-center justify-between mb-5">
        <div className="flex items-center gap-3">
          <h2 className="text-2xl font-bold text-white">直播中</h2>
          <span className="flex items-center gap-1.5 px-2.5 py-0.5 bg-[#ff0055]/20 text-[#ff0055] rounded-full text-xs font-medium">
            <span className="w-1.5 h-1.5 bg-[#ff0055] rounded-full animate-pulse" />
            {liveStreams.length} 个直播
          </span>
        </div>
        <button className="flex items-center gap-1 text-[#8a8a8a] hover:text-[#ff0055] transition-colors text-sm">
          查看更多
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
        {liveStreams.map((stream) => (
          <VideoCard 
            key={stream.id} 
            content={stream} 
            type="live"
            onClick={() => onVideoClick?.(stream)}
          />
        ))}
      </div>
    </section>
  );
}
