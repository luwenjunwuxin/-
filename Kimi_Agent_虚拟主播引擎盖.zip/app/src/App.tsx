import { useState } from 'react';
import { Sidebar } from '@/components/layout/Sidebar';
import { Header } from '@/components/layout/Header';
import { BottomPlayer } from '@/components/player/BottomPlayer';
import { HeroCarousel } from '@/sections/HeroCarousel';
import { LiveSection } from '@/sections/LiveSection';
import { VideoSection } from '@/sections/VideoSection';
import { RadioSection } from '@/sections/RadioSection';
import { ChannelSection } from '@/sections/ChannelSection';
import { Toaster } from '@/components/ui/sonner';
import { toast } from 'sonner';
import './App.css';

function App() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('home');
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTrack, setCurrentTrack] = useState<{
    title: string;
    artist: string;
    thumbnail: string;
    duration: number;
  } | null>(null);

  const handleVideoClick = (content: any) => {
    setCurrentTrack({
      title: content.title,
      artist: content.vtuber.name,
      thumbnail: content.thumbnail,
      duration: 180 // Mock duration
    });
    setIsPlaying(true);
    toast.info(`正在播放: ${content.title}`, {
      description: content.vtuber.name,
    });
  };

  const handleRadioClick = (radio: any) => {
    setCurrentTrack({
      title: radio.title,
      artist: radio.vtuber.name,
      thumbnail: radio.cover,
      duration: 2700 // Mock duration
    });
    setIsPlaying(true);
    toast.info(`正在播放电台: ${radio.title}`, {
      description: radio.vtuber.name,
    });
  };

  const handleSearch = (query: string) => {
    toast.info(`搜索: ${query}`, {
      description: '搜索功能正在开发中...',
    });
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'home':
        return (
          <>
            <HeroCarousel />
            <LiveSection onVideoClick={handleVideoClick} />
            <VideoSection onVideoClick={handleVideoClick} />
            <RadioSection onRadioClick={handleRadioClick} />
            <ChannelSection />
          </>
        );
      case 'channels':
        return (
          <div className="pt-4">
            <h1 className="text-3xl font-bold text-white mb-6">频道</h1>
            <ChannelSection />
          </div>
        );
      case 'playlists':
        return (
          <div className="pt-4">
            <h1 className="text-3xl font-bold text-white mb-6">播放列表</h1>
            <div className="text-[#8a8a8a] text-center py-20">
              <p>播放列表功能即将上线</p>
            </div>
          </div>
        );
      case 'favorites':
        return (
          <div className="pt-4">
            <h1 className="text-3xl font-bold text-white mb-6">收藏夹</h1>
            <div className="text-[#8a8a8a] text-center py-20">
              <p>您还没有收藏任何内容</p>
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-[#0f0f0f]">
      {/* Sidebar */}
      <Sidebar 
        isOpen={sidebarOpen} 
        onClose={() => setSidebarOpen(false)}
        activeTab={activeTab}
        onTabChange={setActiveTab}
      />

      {/* Header */}
      <Header 
        onMenuClick={() => setSidebarOpen(true)}
        onSearch={handleSearch}
      />

      {/* Main Content */}
      <main className="pt-16 pb-24 lg:pl-[240px] min-h-screen">
        <div className="px-4 sm:px-6 lg:px-8 py-6 max-w-[1600px] mx-auto">
          {renderContent()}
        </div>
      </main>

      {/* Bottom Player */}
      <BottomPlayer 
        isPlaying={isPlaying}
        onPlayPause={() => setIsPlaying(!isPlaying)}
        currentTrack={currentTrack}
      />

      {/* Toast */}
      <Toaster 
        position="bottom-right"
        toastOptions={{
          style: {
            background: '#1a1a1a',
            border: '1px solid #3d3d3d',
            color: '#fff',
          },
        }}
      />
    </div>
  );
}

export default App;
