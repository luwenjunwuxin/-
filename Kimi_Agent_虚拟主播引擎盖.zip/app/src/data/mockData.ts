export interface VTuber {
  id: string;
  name: string;
  avatar: string;
  group: string;
  subscribers: string;
  videoCount: string;
  tags: string[];
  socialLinks: {
    youtube?: string;
    twitter?: string;
    bilibili?: string;
  };
}

export interface LiveStream {
  id: string;
  title: string;
  thumbnail: string;
  vtuber: VTuber;
  viewers: string;
  tags: string[];
  isLive: boolean;
}

export interface Video {
  id: string;
  title: string;
  thumbnail: string;
  vtuber: VTuber;
  duration: string;
  publishedAt: string;
  views: string;
  tags: string[];
}

export interface Radio {
  id: string;
  title: string;
  cover: string;
  vtuber: VTuber;
  duration: string;
}

export const vtubers: VTuber[] = [
  {
    id: '1',
    name: 'Gawr Gura',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=gura',
    group: 'Hololive EN',
    subscribers: '4.2M',
    videoCount: '456',
    tags: ['Shorts', 'Gaming', 'Singing'],
    socialLinks: { youtube: '#', twitter: '#', bilibili: '#' }
  },
  {
    id: '2',
    name: 'Usada Pekora',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=pekora',
    group: 'Hololive JP',
    subscribers: '2.8M',
    videoCount: '892',
    tags: ['Shorts', 'Animation', 'Gaming'],
    socialLinks: { youtube: '#', twitter: '#', bilibili: '#' }
  },
  {
    id: '3',
    name: 'Hakos Baelz',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=baelz',
    group: 'Hololive EN',
    subscribers: '1.2M',
    videoCount: '234',
    tags: ['Shorts', 'Talk', 'Gaming'],
    socialLinks: { youtube: '#', twitter: '#', bilibili: '#' }
  },
  {
    id: '4',
    name: '星街彗星',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=suisei',
    group: 'Hololive JP',
    subscribers: '2.1M',
    videoCount: '567',
    tags: ['Original Song', 'Singing', 'Shorts'],
    socialLinks: { youtube: '#', twitter: '#', bilibili: '#' }
  },
  {
    id: '5',
    name: '月之美兔',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=mito',
    group: 'Nijisanji',
    subscribers: '1.5M',
    videoCount: '723',
    tags: ['Talk', 'Gaming', 'Shorts'],
    socialLinks: { youtube: '#', twitter: '#', bilibili: '#' }
  },
  {
    id: '6',
    name: '奏手一弦',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=kanade',
    group: 'Holostars',
    subscribers: '680K',
    videoCount: '345',
    tags: ['Music Cover', 'Gaming', 'Talk'],
    socialLinks: { youtube: '#', twitter: '#', bilibili: '#' }
  }
];

export const liveStreams: LiveStream[] = [
  {
    id: '1',
    title: '【Minecraft】建設大作戦！今日も元気に冒険！',
    thumbnail: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=640&h=360&fit=crop',
    vtuber: vtubers[0],
    viewers: '24.5K',
    tags: ['Gaming', 'Minecraft'],
    isLive: true
  },
  {
    id: '2',
    title: '【歌枠】深夜の癒し歌枠 / Singing Stream',
    thumbnail: 'https://images.unsplash.com/photo-1516280440614-6697288d5d38?w=640&h=360&fit=crop',
    vtuber: vtubers[1],
    viewers: '18.2K',
    tags: ['Singing', 'Karaoke'],
    isLive: true
  },
  {
    id: '3',
    title: '【雑談】週末のお話ししましょう！',
    thumbnail: 'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=640&h=360&fit=crop',
    vtuber: vtubers[2],
    viewers: '12.8K',
    tags: ['Talk', 'Chatting'],
    isLive: true
  },
  {
    id: '4',
    title: '【原神】新イベント攻略！一緒に遊ぼう',
    thumbnail: 'https://images.unsplash.com/photo-1538481199705-c710c4e965fc?w=640&h=360&fit=crop',
    vtuber: vtubers[3],
    viewers: '31.2K',
    tags: ['Gaming', 'Genshin Impact'],
    isLive: true
  }
];

export const videos: Video[] = [
  {
    id: '1',
    title: '【切り抜き】爆笑シーンまとめ #1',
    thumbnail: 'https://images.unsplash.com/photo-1518676590629-3dcbd9c5a5c9?w=640&h=360&fit=crop',
    vtuber: vtubers[0],
    duration: '15:32',
    publishedAt: '2時間前',
    views: '128K',
    tags: ['Clips', 'Funny']
  },
  {
    id: '2',
    title: '【歌ってみた】夜に駆ける / YOASOBI',
    thumbnail: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=640&h=360&fit=crop',
    vtuber: vtubers[3],
    duration: '4:18',
    publishedAt: '5時間前',
    views: '456K',
    tags: ['Cover', 'Singing']
  },
  {
    id: '3',
    title: '【ASMR】癒しの耳かきボイス',
    thumbnail: 'https://images.unsplash.com/photo-1519834785169-98be25ec3f84?w=640&h=360&fit=crop',
    vtuber: vtubers[1],
    duration: '1:02:45',
    publishedAt: '1日前',
    views: '89K',
    tags: ['ASMR', 'Relaxing']
  },
  {
    id: '4',
    title: '【雑談】新衣装お披露目！',
    thumbnail: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=640&h=360&fit=crop',
    vtuber: vtubers[4],
    duration: '2:15:40',
    publishedAt: '2日前',
    views: '234K',
    tags: ['Talk', 'Costume']
  },
  {
    id: '5',
    title: '【ゲーム】ホラゲーで絶叫！',
    thumbnail: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=640&h=360&fit=crop',
    vtuber: vtubers[2],
    duration: '45:22',
    publishedAt: '3日前',
    views: '167K',
    tags: ['Gaming', 'Horror']
  },
  {
    id: '6',
    title: '【弾き語り】オリジナル曲披露',
    thumbnail: 'https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=640&h=360&fit=crop',
    vtuber: vtubers[5],
    duration: '8:45',
    publishedAt: '4日前',
    views: '78K',
    tags: ['Original Song', 'Music']
  }
];

export const radios: Radio[] = [
  {
    id: '1',
    title: 'Gura\'s Lazy Afternoon',
    cover: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=400&h=400&fit=crop',
    vtuber: vtubers[0],
    duration: '45:00'
  },
  {
    id: '2',
    title: 'Pekora Radio #128',
    cover: 'https://images.unsplash.com/photo-1487180144351-b8472da7d491?w=400&h=400&fit=crop',
    vtuber: vtubers[1],
    duration: '1:30:00'
  },
  {
    id: '3',
    title: 'Baelz Morning Show',
    cover: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=400&h=400&fit=crop',
    vtuber: vtubers[2],
    duration: '32:15'
  },
  {
    id: '4',
    title: '星街の音楽部屋',
    cover: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=400&h=400&fit=crop',
    vtuber: vtubers[3],
    duration: '55:30'
  }
];

export const categories = [
  { id: 'all', name: '全部', icon: 'LayoutGrid' },
  { id: 'hololive', name: 'Hololive', icon: 'Heart' },
  { id: 'holostars', name: 'Holostars', icon: 'Star' },
  { id: 'nijisanji', name: 'Nijisanji', icon: 'Sparkles' },
  { id: 'personal', name: '个人势', icon: 'User' }
];

export const navItems = [
  { id: 'home', name: '首页', icon: 'Home' },
  { id: 'channels', name: '频道', icon: 'Users' },
  { id: 'playlists', name: '播放列表', icon: 'ListMusic' },
  { id: 'favorites', name: '收藏夹', icon: 'Heart' }
];
